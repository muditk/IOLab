#!flask/bin/python
from app import myapp
myapp.run(debug=True,host='0.0.0.0')
